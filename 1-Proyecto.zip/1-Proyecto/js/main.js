'use strict'

window.addEventListener("load",function(){
    const swiper = new Swiper('.swiper', {
        slidesPerView: 3,
        spaceBetween: 30,
        // Optional parameters
        direction: 'horizontal',
        loop: true,
      
        // If we need pagination
        pagination: {
          el: '.swiper-pagination',
        },
      
        // Navigation arrows
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      
        // And if we need scrollbar
        scrollbar: {
          el: '.swiper-scrollbar',
        },
    });

    //LOGIN REGISTER
    let btnRegister = this.document.querySelector("#register-btn");
    let btnLogin = this.document.querySelector("#login-btn");
    let formBox = this.document.querySelectorAll(".formularios-cuenta");

    if(formBox.length > 0){
      btnRegister.addEventListener("click",function(){
        for(let i = 0; i<formBox.length; i++){
          formBox[i].style.transform = "translateY(0px)";
        }
      });
      btnLogin.addEventListener("click",function(){
        for(let i = 0; i<formBox.length; i++){
          formBox[i].style.transform = "translateY(-820px)";
        }
      })
    }


    //PRODUCTS
    let productos = this.document.querySelectorAll(".productos .items .articulo");
    let index = this.document.querySelectorAll(".indexUnico");
    if(productos.length > 0){
      for(let i = 0; i<productos.length; i++){
        productos[i].addEventListener("click",function(){
          if(index.length > 0){
            window.location.href = "pages/producto.html";
          }else{
            window.location.href = "producto.html";
          }
        })
      }
    }
})
